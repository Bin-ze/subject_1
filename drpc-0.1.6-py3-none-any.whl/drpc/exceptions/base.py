#!/usr/bin/env python3
# -*- coding:UTF-8 -*-
# @Date    : 2021-07-19 11:10:31
# @Author  : Shenchucheng (chuchengshen@fuzhi.ai)
# @Desc    : base exceptions


class BaseDrpcException(Exception):
    code: int
    message: str


class RequestParamLackError(BaseDrpcException):
    code = 208
    message = "requests lack of param"


class RequestParamInvalidError(BaseDrpcException):
    code = 208
    message = "requests params type error"


class ContentInvalidError(BaseDrpcException):
    code = 208
    message = "invalid value error"


class UnauthorizedError(BaseDrpcException):
    code = 401
    message = "user not login"