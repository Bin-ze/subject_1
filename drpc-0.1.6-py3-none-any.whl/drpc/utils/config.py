#!/usr/bin/env python3
# -*- coding:UTF-8 -*-
# @Date    : 2021-01-04 18:00:06
# @Author  : Shen Chucheng (chuchengshen@fuzhi.ai)
# @Desc    : parse config


import yaml

from typing import Optional
from urllib.parse import urlparse
from urllib.request import urlopen


def load_stream(path: str, encoding="utf-8") -> str:
    url_scheme = urlparse(path).scheme
    if url_scheme == "file":
        file = urlparse(path).netloc + urlparse(path).path
        with open(file, encoding=encoding) as fh:
            data = fh.read()
    elif len(url_scheme) <= 1:
        with open(path, encoding=encoding) as fh:
            data = fh.read()
    elif url_scheme in ("http", "https"):
        data = urlopen(path).read()
    else:
        raise ValueError
    if isinstance(data, bytes):
        data = data.decode(encoding)
    return data


def load_config(path: Optional[str] = None, encoding: str = "utf-8"):
    if path is None:
        path = "config.yaml"
    config = yaml.load(load_stream(path, encoding), Loader=yaml.SafeLoader)
    return config


class Config(object):

    _instance = None

    def __new__(cls, path: Optional[str] = None, encoding: str = "utf-8") -> None:
        if cls._instance is None:
            cls._instance = load_config(path=path, encoding=encoding)
        return cls._instance
