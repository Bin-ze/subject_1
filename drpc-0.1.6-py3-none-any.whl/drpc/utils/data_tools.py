#!/usr/bin/env python3
# -*- coding:UTF-8 -*-
# @Date    : 2021-03-11 10:03:19
# @Author  : Shen Chucheng (chuchengshen@fuzhi.ai)
# @Desc    : data tools


import json
import datetime

from uuid import UUID
from functools import partial


class JsonEncoder(json.JSONEncoder):
    def default(self, obj):
        try:
            return JSON_TRANS_FUNC[type(object)](obj)
        except KeyError:
            if hasattr(obj, "__dataclass_fields__"):
                JSON_TRANS_FUNC[type(object)] = trans_dataclass
                return trans_dataclass(obj)
            return json.JSONEncoder.default(self, obj)


dumps = partial(json.dumps, cls=JsonEncoder, ensure_ascii=False)


def trans_dataclass(obj):
    return obj.__dict__


def trans_bytes(obj: bytes):
    return str(obj, encoding="utf-8")


def trans_datetime(obj: datetime.datetime):
    return obj.strftime("%Y-%m-%d %H:%M:%S")


def trans_date(obj: datetime.date):
    return obj.strftime("%Y-%m-%d")


def trans_uuid(obj: UUID):
    return obj.hex


JSON_TRANS_FUNC = {
    bytes: trans_bytes,
    datetime.datetime: trans_datetime,
    datetime.date: trans_date,
}
