#!/usr/bin/env python3
# -*- coding:UTF-8 -*-
# @Date    : 2021-07-17 13:17:29
# @Author  : Shenchucheng (chuchengshen@fuzhi.ai)
# @Desc    : define the context var


from uuid import uuid4
from typing import Dict, Optional
from contextvars import ContextVar


TRACE: ContextVar[Optional[Dict]] = ContextVar("request-trace")

REQUEST = ContextVar("request")
HEADERS = ContextVar("request-headers")
COOKIES = ContextVar("request-cookies")


def send_trace(trace: Dict):
    if "x-request-id" not in trace:
        trace["x-request-id"] = uuid4().hex
    TRACE.set(trace)


def get_trace() -> Dict:
    trace = TRACE.get(None)
    if trace is None:
        trace = dict((("x-request-id", uuid4().hex),))
        TRACE.set(trace)
    else:
        trace = format_trace(trace)
    return trace


def format_trace(trace: Dict) -> Dict:
    return dict((k, v) for (k, v) in trace.items() if k.startswith("x-"))
