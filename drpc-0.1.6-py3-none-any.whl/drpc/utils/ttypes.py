#!/usr/bin/env python3
# -*- coding:UTF-8 -*-
# @Date    : 2021-07-18 23:38:52
# @Author  : Shenchucheng (chuchengshen@fuzhi.ai)
# @Desc    : parse function


import inspect
import logging

from functools import partial
from typing import Any, Callable, Optional, Union
from typing import Dict, List, Tuple

from drpc.exceptions import RequestParamInvalidError, RequestParamLackError


def gen_func_to_format_params(func: Callable) -> Callable:
    # if hasattr(func, "__annotations__"):
    #     annotations = func.__annotations__
    # else:
    #     annotations = func.__func__.__annotations__

    # if hasattr(func, "__defaults__"):
    #     defaults = func.__defaults__
    # else:
    #     defaults = func.__func__.__defaults__
    signature = inspect.signature(func)
    annotations = dict()
    parameters = set()
    not_default = set()
    check_invalid = True
    for name, sig in signature.parameters.items():
        parameters.add(name)
        if sig.kind.value == 3:
            continue
        if sig.kind.value == 4:
            check_invalid = False
            continue
        if sig.annotation != inspect._empty:
            annotations[name] = sig.annotation
        if sig.default == inspect._empty:
            not_default.add(name)
        else:
            if name not in annotations:
                annotations[name] = type(sig.default)
    trans = dict((k, get_trans_func(annotations[k])) for k in annotations)

    def format_func(kwargs: Dict) -> Dict:
        for key in not_default:
            if key not in kwargs:
                msg = f"field `{key}` must be assiged"
                raise RequestParamLackError(msg)
        if check_invalid:
            for key in kwargs:
                if key not in parameters:
                    msg = f"field named `{key}` is invalid"
                    raise RequestParamInvalidError(msg)

        for key in annotations:
            if key not in kwargs:
                continue
            val = kwargs[key]
            if not isinstance(val, str):
                continue
            try:
                kwargs[key] = trans[key](val)
            except Exception:
                msg = f"fail to convert value {val} to {annotations[key]}"
                logging.error(msg, exc_info=True)
                raise RequestParamInvalidError(msg)
        return kwargs

    format_func.__name__ = f"{func.__name__}_format_params"
    return format_func


def return_self(x: Any) -> Any:
    return x


def dataclass_format(x: Any) -> Dict:
    return x.__dict__


def trans_value(v: Any, _type: type) -> Any:
    if v is None and type(None) in _type.__args__:
        return v
    for __type in _type.__args__:
        try:
            return _TRANS_FUNC_MAPPING[__type](v)
        except Exception:
            continue
    raise NotImplementedError


def parse_union(_type: type, mapping: Optional[Dict] = None) -> Callable:
    if mapping is None:
        mapping = _TRANS_FUNC_MAPPING
    for __type in _type.__args__:
        if mapping.get(__type, None) is None:
            if __type.__module__ == "typing" and __type.__origin__ == Union:
                mapping[__type] = parse_union(__type)
    mapping[_type] = partial(trans_value, _type=_type)
    return mapping[_type]


def get_trans_func(_type: type, mapping: Optional[Dict] = None) -> Callable:
    if mapping is None:
        mapping = _TRANS_FUNC_MAPPING
    if mapping.get(_type):
        return mapping[_type]
    elif _type.__module__ == "typing":
        if _type.__origin__ == Union:
            return parse_union(_type)
        else:
            register(_type, _type.__origin__)
            return _type.__origin__
            # raise NotImplementedError
    elif hasattr(_type, "__dataclass_fields__"):
        register(_type, dataclass_format)
        return dataclass_format
    else:
        if _type not in __WARNINGS:
            __WARNINGS.add(_type)
            logging.warning("Not set func for type of {} to trans".format(_type))
        return _type


def register(_type, func):
    if not isinstance(_type, type):
        logging.warning("you register a non-type value of {} into TRANS_FUNC")
    if not callable(func):
        raise TypeError("func {} is not callable".format(func))
    _TRANS_FUNC_MAPPING[_type] = func


_TRANS_FUNC_MAPPING = {
    str: str,
    int: int,
    float: float,
    dict: dict,
    list: list,
    tuple: tuple,
    Dict: dict,
    List: list,
    Tuple: tuple,
    bool: bool,
    type(None): return_self,
    None: return_self,
}


__WARNINGS = set()
