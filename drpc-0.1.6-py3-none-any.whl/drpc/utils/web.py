#!/usr/bin/env python3
# -*- coding:UTF-8 -*-
# @Date    : 2021-09-08 12:37:50
# @Author  : Shen Chucheng (chuchengshen@fuzhi.ai)
# @Desc    : 


import ssl

from typing import Optional


def load_ssl_context(
    cert_file: str,
    pkey_file: Optional[str] = None,
    protocol: Optional[int] = None,
    **kwargs
) -> ssl.SSLContext:
    if protocol is None:
        protocol = ssl.PROTOCOL_TLS_SERVER

    ctx = ssl.SSLContext(protocol)
    ctx.load_cert_chain(cert_file, pkey_file, **kwargs)
    return ctx


# def generate_adhoc_ssl_context() -> "ssl.SSLContext":
#     """Generates an adhoc SSL context for the development server."""
#     import tempfile
#     import atexit

#     cert, pkey = generate_adhoc_ssl_pair()

#     from cryptography.hazmat.primitives import serialization

#     cert_handle, cert_file = tempfile.mkstemp()
#     pkey_handle, pkey_file = tempfile.mkstemp()
#     atexit.register(os.remove, pkey_file)
#     atexit.register(os.remove, cert_file)

#     os.write(cert_handle, cert.public_bytes(serialization.Encoding.PEM))
#     os.write(
#         pkey_handle,
#         pkey.private_bytes(
#             encoding=serialization.Encoding.PEM,
#             format=serialization.PrivateFormat.TraditionalOpenSSL,
#             encryption_algorithm=serialization.NoEncryption(),
#         ),
#     )

#     os.close(cert_handle)
#     os.close(pkey_handle)
#     ctx = load_ssl_context(cert_file, pkey_file)
#     return ctx
