#!/usr/bin/env python3
# -*- coding:UTF-8 -*-
# @Date    : 2020-11-24 19:54:44
# @Author  : Shen Chucheng (chuchengshen@fuzhi.ai)
# @Desc    : parse logging


import os
import time
try:
    import fcntl
except ModuleNotFoundError:
    import drpc.utils._fcntl as fcntl
import logging
import logging.handlers

from logging import Formatter
from shutil import copyfile
from typing import Optional
from logging.handlers import TimedRotatingFileHandler, RotatingFileHandler


__PARSE__ = False


class MpTimedRotatingFileHandler(TimedRotatingFileHandler):
    def __init__(self, *args, **kwags):
        super(MpTimedRotatingFileHandler, self).__init__(*args, **kwags)
        self.lock_path = os.path.join(os.path.dirname(self.baseFilename), ".loglockfile")

    def doRollover(self):
        """
        do a rollover; in this case, a date/time stamp is appended to the filename
        when the rollover happens.  However, you want the file to be named for the
        start of the interval, not the current time.  If there is a backup count,
        then we have to get a list of matching filenames, sort them and remove
        the one with the oldest suffix.
        """
        if self.stream:
            self.stream.close()
            self.stream = None
        # get the time that this sequence started at and make it a TimeTuple
        currentTime = int(time.time())
        dstNow = time.localtime(currentTime)[-1]
        t = self.rolloverAt - self.interval
        if self.utc:
            timeTuple = time.gmtime(t)
        else:
            timeTuple = time.localtime(t)
            dstThen = timeTuple[-1]
            if dstNow != dstThen:
                if dstNow:
                    addend = 3600
                else:
                    addend = -3600
                timeTuple = time.localtime(t + addend)
        dfn = self.rotation_filename(self.baseFilename + "." + time.strftime(self.suffix, timeTuple))
        # if os.path.exists(dfn):
        #     os.remove(dfn)
        # self.rotate(self.baseFilename, dfn)
        if not os.path.exists(dfn):
            try:
                self.rotate(self.baseFilename, dfn)
            except FileNotFoundError:
                pass
        if self.backupCount > 0:
            for s in self.getFilesToDelete():
                try:
                    os.remove(s)
                except FileNotFoundError:
                    pass
        if not self.delay:
            self.stream = self._open()
        newRolloverAt = self.computeRollover(currentTime)
        while newRolloverAt <= currentTime:
            newRolloverAt = newRolloverAt + self.interval
        # If DST changes and midnight or weekly rollover, adjust for this.
        if (self.when == "MIDNIGHT" or self.when.startswith("W")) and not self.utc:
            dstAtRollover = time.localtime(newRolloverAt)[-1]
            if dstNow != dstAtRollover:
                if not dstNow:  # DST kicks in before next rollover, so we need to deduct an hour
                    addend = -3600
                else:  # DST bows out before next rollover, so we need to add an hour
                    addend = 3600
                newRolloverAt += addend
        self.rolloverAt = newRolloverAt


class MpRotatingFileHandler(RotatingFileHandler):
    def __init__(self, *args, **kwags):
        super(MpRotatingFileHandler, self).__init__(*args, **kwags)
        self.lock_path = os.path.join(os.path.dirname(self.baseFilename), ".loglockfile")

    def emit(self, record):
        """
        Emit a record.

        Output the record to the file, catering for rollover as described
        in doRollover().
        """
        f = None
        try:
            f = open(self.lock_path, "wb")
            fcntl.flock(f.fileno(), fcntl.LOCK_EX)
            logging.FileHandler.emit(self, record)
            if self.shouldRollover(record):
                self.doRollover()

        except Exception:
            self.handleError(record)
        finally:
            if f:
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)

    def rotate(self, source, dest):
        copyfile(source, dest)
        # clear the log file
        with open(source, "wb"):
            pass


def update_logging_handles():
    logging.handlers.TimedRotatingFileHandler = MpTimedRotatingFileHandler
    logging.handlers.RotatingFileHandler = MpRotatingFileHandler


def parse(
    level: int = 20,
    file_name: Optional[str] = None,
    fmt: str = "%(asctime)s %(levelname)s: %(message)s",
    rotate_when: str = "H",
    rotate_interval: int = 1,
    file_num_backups: int = 50,
    console: bool = True,
    datafmt: str = "%Y-%m-%d %H:%M:%S",
):
    global __PARSE__
    if __PARSE__:
        return
    __PARSE__ = True
    handlers = list()
    formatter = Formatter(fmt, datafmt)

    if file_name:
        handler = TimedRotatingFileHandler(
            filename=file_name,
            when=rotate_when,
            interval=rotate_interval,
            backupCount=file_num_backups,
        )
        # handler.suffix = "%Y-%m-%d_%H-%M.log"
        # handler.extMatch = re.compile(r"^\d{4}-\d{2}-\d{2}_\d{2}-\d{2}.log$")
        handlers.append(handler)
    if console:
        handler = logging.StreamHandler()
        handlers.append(handler)
    for handler in handlers:
        handler.setFormatter(formatter)
        handler.setLevel(level)
    logging.basicConfig(level=level, handlers=handlers, datefmt=datafmt)


def main():
    parse(10, "test.log", console=True)
    logging.debug("debug")
    logging.info("info")
    logging.warning("warning")
    logging.error("error")


if __name__ == "__main__":
    main()
