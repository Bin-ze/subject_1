#!/usr/source/env python3
# -*- coding:UTF-8 -*-
# @Date    : 2021-05-14 10:22:29
# @Author  : Shen Chucheng (chuchengshen@fuzhi.ai)
# @Desc    : async web client


from aiohttp import (
    ClientSession,
    AsyncResolver,
    TCPConnector,
    ServerDisconnectedError,
)
from typing import Any, Callable, Coroutine, Dict, Union
from uuid import uuid4

from .context import get_trace


def default_connecter() -> TCPConnector:
    return TCPConnector(
        resolver=AsyncResolver(),  # depend on aiodns
        enable_cleanup_closed=True,
    )


def set_trace_header(fn: Callable):
    def request(*args, **kwargs):
        headers = kwargs.get("headers")
        if headers is None:
            headers = get_trace()
            kwargs["headers"] = headers
        elif "x-request-id" not in headers:
            headers.update(get_trace())
        return fn(*args, **kwargs)

    request.__name__ = fn.__name__
    request.__annotations__ = fn.__annotations__
    return request


class Session(ClientSession):
    def __init__(self, **kwargs) -> None:
        if kwargs.get("connector") is None:
            kwargs["connector"] = default_connecter()
        super().__init__(**kwargs)

    @set_trace_header
    def get(self, *agrs, **kwargs) -> Coroutine:
        return super().get(*agrs, **kwargs)

    @set_trace_header
    def options(self, *agrs, **kwargs) -> Coroutine:
        return super().options(*agrs, **kwargs)

    @set_trace_header
    def head(self, *agrs, **kwargs) -> Coroutine:
        return super().head(*agrs, **kwargs)

    @set_trace_header
    def post(self, *agrs, **kwargs) -> Coroutine:
        return super().post(*agrs, **kwargs)

    @set_trace_header
    def put(self, *agrs, **kwargs) -> Coroutine:
        return super().put(*agrs, **kwargs)

    @set_trace_header
    def patch(self, *agrs, **kwargs) -> Coroutine:
        return super().patch(*agrs, **kwargs)

    @set_trace_header
    def delete(self, *agrs, **kwargs) -> Coroutine:
        return super().delete(*agrs, **kwargs)
