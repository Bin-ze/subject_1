#!/usr/bin/env python3
# -*- coding:UTF-8 -*-
# @Date    : 2021-03-08 15:21:50
# @Author  : Shen Chucheng (chuchengshen@fuzhi.ai)
# @Desc    : aiohttp auth request render


from typing import Callable, Optional

from drpc.exceptions import UnauthorizedError
from drpc.web.convertor.aiohttp_convertor import Request, request_render
from drpc.web.render import REQUEST_RENDER
from drpc.component.auth.base import AuthToken


def auth_request_render(
    auth_token: Optional[AuthToken] = None,
    name: str = "auth"
) -> Callable:

    if auth_token is None:
        auth_token = AuthToken()

    async def _auth_request_render(request: Request):
        token = request.headers.get("token")
        if not token:
            raise UnauthorizedError("oauth token not found")
        else:
            user_info = auth_token.decode(token)
        user_id = user_info["user_id"]
        kwargs = await request_render(request)
        kwargs["user_id"] = user_id
        return kwargs
    _auth_request_render.__name__ = "auth_request_render"
    if name:
        REQUEST_RENDER.register(name, _auth_request_render)
    return _auth_request_render
