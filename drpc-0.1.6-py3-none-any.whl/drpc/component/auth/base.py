#!/usr/bin/env python3
# -*- coding:UTF-8 -*-
# @Date    : 2021-03-08 15:21:50
# @Author  : Shen Chucheng (chuchengshen@fuzhi.ai)
# @Desc    : account auth


import jwt
import logging

from hashlib import sha256
from jwt import decode as jwt_decode, encode as jwt_encode
from datetime import datetime, timedelta
from drpc.exceptions import UnauthorizedError

from typing import Optional, Dict



def passwd_hash(passwd: str):
    h = sha256()
    h.update(bytes(passwd, encoding="utf-8"))
    return h.hexdigest()


class AuthToken(object):
    def __init__(self, **kwargs):
        self.token_secret = kwargs.get("token_secret", "Oe-f5Pdj11iO8f4SPavV-a3YZoNs4Rm1G_xps-s3DqE")

    def encode(self, **kwargs) -> str:
        utcnow = datetime.utcnow
        exp_days = kwargs.pop("exp_days", 1)
        exp_hours = kwargs.pop("exp_hours", 0)
        if exp_hours and exp_days == 1:
            exp_time = utcnow() + timedelta(hours=int(exp_hours), seconds=30)
        else:
            exp_time = utcnow() + timedelta(days=int(exp_days), seconds=30)

        payload = {
            "exp": exp_time,
            "nbf": utcnow() - timedelta(seconds=10),
            "iat": utcnow(),
            "iss": "auth: ss",
            "data": kwargs,
        }
        return jwt_encode(payload, self.token_secret, algorithm="HS256")

    def decode(self, auth_token: str) -> Dict:
        try:
            payload = jwt_decode(auth_token, self.token_secret, algorithms=["HS256"], leeway=timedelta(seconds=10))
            return payload["data"]
        except jwt.ExpiredSignatureError:
            raise UnauthorizedError("Invalid token with expired signature")
        except jwt.InvalidTokenError:
            raise UnauthorizedError("Invalid token")
