#!/usr/bin/env python3
# -*- coding:UTF-8 -*-
# @Date    : 2021-07-13 11:42:46
# @Author  : Shenchucheng (chuchengshen@fuzhi.ai)
# @Desc    : drpc-web


from drpc.web.convertor.aiohttp_convertor import AiohttpConvertor as HttpServer
