#!/usr/bin/env python3
# -*- coding:UTF-8 -*-
# @Date    : 2021-07-13 11:42:46
# @Author  : Shenchucheng (chuchengshen@fuzhi.ai)
# @Desc    : request/response/error render functions


import abc
from typing import Any, Callable, Coroutine, Dict, Optional


class Renders(object):
    def __init__(self, name):
        self._name = name
        self._render_dict = {}

    @property
    def name(self):
        return self._name

    @property
    def render_dict(self):
        return self._render_dict

    @property
    def render_default(self) -> Callable:
        return self._render_dict.get("default") or self.get_defalt_random()

    @render_default.setter
    def render_default(self, render):
        self.register("default", render)

    def register(self, name: str, render: Callable):
        if name not in self._render_dict.values():
            if callable(render):
                self._render_dict[name] = render
            else:
                raise TypeError("render must be callable")
        else:
            raise ValueError("name {} already exist".format(name))

    def get(self, name: str):
        return self._render_dict[name]

    def get_defalt_random(self) -> Callable:
        if "default" in self._render_dict:
            raise ValueError("default render already set")
        for render in self._render_dict.values():
            self._render_dict["default"] = render
            return render
        raise ValueError("can not set random render with empty render_dict")

    def __len__(self):
        return len(self._render_dict)

    def __bool__(self):
        return bool(self._render_dict)

    def __contains__(self, item):
        return item in self._render_dict

REQUEST_RENDER = Renders("request")
RESPONSE_RENDER = Renders("response")
ERROR_RENDER = Renders("error")


def return_render(response_render: Coroutine, error_render: Callable):
    def _wrap(func: Callable):
        async def wrap(*args, **kwargs):
            try:
                ret = await func(*args, **kwargs)
                return response_render(ret)
            except BaseException as e:
                return error_render(e)

        wrap.__name__ = func.__name__
        return wrap

    _wrap.__name__ = "return_render_wrap"
    return _wrap


async def request_render(self, request: "Response") -> Dict:
    """Parse request to a key-value object."""
    raise NotImplementedError


def response_render(self, ret: Any) -> "Response":
    """Convert function returned to web response."""
    raise NotImplementedError


def error_render(self, error: BaseException) -> "Response":
    """Handle error and convert it to web response."""
    raise NotImplementedError


class Response(abc.ABCMeta):
    """web response"""


class Request(abc.ABCMeta):
    """request"""
