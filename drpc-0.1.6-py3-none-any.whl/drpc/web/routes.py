#!/usr/bin/env python3
# -*- coding:UTF-8 -*-
# @Date    : 2021-07-13 11:42:46
# @Author  : Shenchucheng (chuchengshen@fuzhi.ai)
# @Desc    : base web server route


from typing import Callable, Iterable, Optional, Union


class WebRoutes(object):

    _methods_allow = ("GET", "POST", "DELETE", "PATCH", "PUT", "OPTIONS", "HAED")
    _routes = dict()

    def add_route(
        self,
        func: Callable,
        uri: str,
        methods: Union[Iterable[str], str] = "GET",
        request_render: Union[Callable, str] = "default",
        response_render: Union[Callable, str] = "default",
        error_render: Union[Callable, str] = "default",
    ) -> None:
        """A method to register functions with uri and methods into routes.

        Args:
            func (Callable): a function to convert to hanlder
            uri (str): path of the URL
            methods (Union[Iterable[str], str], optional): http methods
            request_render (Union[Callable, str], optional): a function to parse request to kwargs
            response_render (Union[Callable, str], optional): a function to convert return to web response
            error_render (Union[Callable, str], optional): a function to handle error

        Raises:
            ValueError: raise ValueError when method not in methods allowed
            TypeError: raise TypeError when render is not callable
        """
        if isinstance(methods, str):
            methods = (methods,)

        # if request_render is not None:
        #     if not callable(request_render):
        #         raise TypeError("{} is not callable".format(request_render))

        # if response_render is not None:
        #     if not callable(response_render):
        #         raise TypeError("{} is not callable".format(response_render))

        for method in methods:
            method = method.upper()
            if method not in self._methods_allow:
                raise ValueError("Method {} is not allow".format(method))
            key = (uri, method)
            if key not in self._routes:
                self._routes[key] = func, request_render, response_render, error_render

    def route(
        self,
        uri: str,
        methods: Union[Iterable[str], str] = "GET",
        request_render: Union[Callable, str] = "default",
        response_render: Union[Callable, str] = "default",
        error_render: Union[Callable, str] = "default",
    ):
        """Decorate a function to add it to routes.

        Args:
            uri (str): path of the URL
            methods (Union[Iterable[str], str], optional): http methods
            request_render (Union[Callable, str], optional): a function to parse request to kwargs
            response_render (Union[Callable, str], optional): a function to convert return to web response
            error_render (Union[Callable, str], optional): a function to handle error
        """

        def wrap(func):
            self.add_route(func, uri, methods, request_render, response_render, error_render)
            return func

        return wrap

    def get(self, uri: str, *args, **kwargs):
        """Decorate a function to add it to routes with "GET" method.

        Args:
            uri (str): path of the URL
            methods (Union[Iterable[str], str], optional): http methods
        """

        def wrap(func):
            self.add_route(func, uri, methods=("get",), *args, **kwargs)
            return func

        wrap.__name__ = "get"
        return wrap

    def post(self, uri: str, *args, **kwargs):
        """Decorate a function to add it to routes with "post" method.

        Args:
            uri (str): path of the URL
            methods (Union[Iterable[str], str], optional): http methods
        """

        def wrap(func):
            self.add_route(func, uri, methods=("post",), *args, **kwargs)
            return func

        wrap.__name__ = "post"
        return wrap

    def patch(self, uri: str, *args, **kwargs):
        """Decorate a function to add it to routes with "patch" method.

        Args:
            uri (str): path of the URL
            methods (Union[Iterable[str], str], optional): http methods
        """

        def wrap(func):
            self.add_route(func, uri, methods=("patch",), *args, **kwargs)
            return func

        wrap.__name__ = "patch"
        return wrap

    def delete(self, uri: str, *args, **kwargs):
        """Decorate a function to add it to routes with "delete" method.

        Args:
            uri (str): path of the URL
            methods (Union[Iterable[str], str], optional): http methods
        """

        def wrap(func):
            self.add_route(func, uri, methods=("delete",), *args, **kwargs)
            return func

        wrap.__name__ = "delete"
        return wrap

    def put(self, uri: str, *args, **kwargs):
        """Decorate a function to add it to routes with "put" method.

        Args:
            uri (str): path of the URL
            methods (Union[Iterable[str], str], optional): http methods
        """

        def wrap(func):
            self.add_route(func, uri, methods=("put",), *args, **kwargs)
            return func

        wrap.__name__ = "put"
        return wrap

    def head(self, uri: str, *args, **kwargs):
        """Decorate a function to add it to routes with "head" method.

        Args:
            uri (str): path of the URL
            methods (Union[Iterable[str], str], optional): http methods
        """

        def wrap(func):
            self.add_route(func, uri, methods=("head",), *args, **kwargs)
            return func

        wrap.__name__ = "head"
        return wrap

    def options(self, uri: str, *args, **kwargs):
        """Decorate a function to add it to routes with "options" method.

        Args:
            uri (str): path of the URL
            methods (Union[Iterable[str], str], optional): http methods
        """

        def wrap(func):
            self.add_route(func, uri, methods=("options",), *args, **kwargs)
            return func

        wrap.__name__ = "options"
        return wrap
