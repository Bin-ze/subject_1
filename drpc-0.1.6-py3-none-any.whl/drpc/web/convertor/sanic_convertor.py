#!/usr/bin/env python3
# -*- coding:UTF-8 -*-
# @Date    : 2021-07-18 23:07:49
# @Author  : Shenchucheng (chuchengshen@fuzhi.ai)
# @Desc    : convert to sanic web service


from sanic import Sanic
from .convertor import Convertor


class SanicConvertor(Convertor):
    _app = None

    def init_app(self, *args, **kwargs):
        self._app = Sanic(*args, **kwargs)

    def start(self):
        if self._app is None:
            app = self._app = Sanic(__name__)
        app = self._app
        for (uri, method), func in self._routes.items():

            async def handler(handler):
                return

            handler.__name__ = func.__name__
            app.add_route(handler, uri, method)
