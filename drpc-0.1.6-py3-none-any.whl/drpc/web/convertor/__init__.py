#!/usr/bin/env python3
# -*- coding:UTF-8 -*-
# @Date    : 2021-07-18 23:07:49
# @Author  : Shenchucheng (chuchengshen@fuzhi.ai)
# @Desc    : create web server class


import inspect
import logging

from typing import Any, Callable, Dict, Optional, Tuple

from drpc.web.base import BaseServer, create_sock, send_trace
from drpc.web.routes import WebRoutes


class Convertor(BaseServer, WebRoutes):
    """Create web server from routes."""

    def register(self, server: Any, prefix: str = ""):

        """Register api from object instance and parse routes from function docstring.

        Args:
            server (Any): server object instance
            prefix (Optional[str], optional): uri prefix

        Raises:
            TypeError: raise TypeError if server is a type object
            ValueError: raise ValueError if prefix not start with /
        """
        if prefix:
            prefix = prefix.strip("/")
            prefix = "/" + prefix

        if isinstance(server, dict):
            for key, val in server.items():
                key = key.strip("/")
                key = "/".join((prefix, key))
                self.register(val, prefix=key)
            return

        if inspect.isfunction(server) or inspect.iscoroutinefunction(server):
            server = [server]

        elif inspect.isclass(server):
            try:
                server = server()
            except Exception:
                raise TypeError("can not register server with a class witch can not initialise automatically")

        if not isinstance(server, (list, tuple)): 
            all_methods = dir(server)
            _server = list()
            for method in all_methods:
                if method.startswith("__"):
                    continue
                method = getattr(server, method)
                if not callable(method):
                    continue
                _server.append(method)
            server = _server

        for method in server:
            self._register(method, prefix)

    def _register(self, method: Callable, prefix, ):
            doc: str = method.__doc__
            if not doc:
                return
            for line in doc.splitlines():
                line = line.strip()
                if line.startswith("HTTP: /"):
                    uri, *args = line[6:].split()
                    uri = prefix + uri
                    methods, rrequest, rresponse, rerror, *_ = [*args, *((None,) * 4)]
                    if methods is None:
                        methods = "GET"
                    elif "," in methods:
                        methods = methods.split(",")
                    rrequest = rrequest or "default"
                    rresponse = rresponse or "default"
                    rerror = rerror or "default"
                    self.add_route(method, uri, methods, rrequest, rresponse, rerror)
                    break