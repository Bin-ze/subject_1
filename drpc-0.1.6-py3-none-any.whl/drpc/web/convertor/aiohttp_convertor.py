#!/usr/bin/env python3
# -*- coding:UTF-8 -*-
# @Date    : 2021-07-18 23:07:49
# @Author  : Shenchucheng (chuchengshen@fuzhi.ai)
# @Desc    : convert to aiohttp web service


import io
import ssl
import json
import socket
import asyncio
import logging
import traceback

from uuid import uuid4
from typing import Any, Callable, Dict, Optional, Tuple, Union
from functools import partial
from aiohttp.web import (
    SockSite,
    AppRunner,
    Application,
    Response,
    Request,
    json_response,
)
from concurrent.futures import ThreadPoolExecutor

from drpc.exceptions import BaseDrpcException, ContentInvalidError
from drpc.utils.web import load_ssl_context
from drpc.web.render import REQUEST_RENDER, RESPONSE_RENDER, ERROR_RENDER
from drpc.web.convertor import Convertor, create_sock, send_trace
from drpc.utils.ttypes import gen_func_to_format_params
from drpc.utils.data_tools import dumps


class AiohttpConvertor(Convertor):
    def _init_app(self, *args, **kwargs) -> Application:
        self._app = Application(*args, **kwargs)
        return self._app

    def _init_executor_pool(self, executor_workers: Optional[int] = None) -> ThreadPoolExecutor:
        if executor_workers:
            self._executor_pools = ThreadPoolExecutor(executor_workers)
        return self._executor_pools

    def _init_routes(self) -> None:
        """Create the web handle function basic the function name."""
        for (uri, method), (func, *renders) in self._routes.items():
            self._add_route(uri, method, func, *renders)

    def _add_route(
        self,
        uri: str,
        method: str,
        func: Callable,
        request_render: Union[Callable, str] = "default",
        response_render: Union[Callable, str] = "default",
        error_render: Union[Callable, str] = "default",
    ) -> None:
        if isinstance(request_render, str):
            request_render = REQUEST_RENDER.get(request_render)
        if isinstance(response_render, str):
            response_render = RESPONSE_RENDER.get(response_render)
        if isinstance(error_render, str):
            error_render = ERROR_RENDER.get(error_render)
        format_params_func = gen_func_to_format_params(func)
        # TODO check url args
        if not asyncio.iscoroutinefunction(func):
            if self._executor_pools:

                async def handler(request: Request, *args, **kwargs) -> Response:
                    try:
                        _kwargs = await request_render(request)
                        _kwargs = format_params_func(_kwargs)
                        loop = asyncio.get_running_loop()
                        _func = partial(
                            func,
                            *args,
                            **kwargs,
                            **_kwargs,
                        )
                        ret = await loop.run_in_executor(
                            self._executor_pools,
                            _func,
                        )
                        return response_render(ret)
                    except BaseException as e:
                        return error_render(e)

            else:

                async def handler(request: Request, *args, **kwargs) -> Response:
                    try:
                        _kwargs = await request_render(request)
                        _kwargs = format_params_func(_kwargs)
                        ret = func(*args, **kwargs, **_kwargs)
                        return response_render(ret)
                    except BaseException as e:
                        return error_render(e)

        else:

            async def handler(request: Request, *args, **kwargs) -> Response:
                try:
                    _kwargs = await request_render(request)
                    _kwargs = format_params_func(_kwargs)
                    ret = await func(*args, **kwargs, **_kwargs)
                    return response_render(ret)
                except BaseException as e:
                    return error_render(e)

        handler.__name__ = func.__name__
        self._app.router.add_route(method=method, path=uri, handler=handler)
        logging.debug("register uri: %s, method: %s, function: %s", uri, method, func)


    def _set_default_render(self) -> None:
        if "default" not in REQUEST_RENDER:
            REQUEST_RENDER.render_default = request_render
        if "json" not in REQUEST_RENDER:
            REQUEST_RENDER.register("json", json_request_render)
        if "form" not in REQUEST_RENDER:
            REQUEST_RENDER.register("form", form_request_render)
        if "simple" not in REQUEST_RENDER:
            REQUEST_RENDER.register("simple", simple_request_render)
        if "default" not in RESPONSE_RENDER:
            RESPONSE_RENDER.render_default = response_render
        if "page" not in RESPONSE_RENDER:
            RESPONSE_RENDER.register("page", page_response_render)
        if "default" not in ERROR_RENDER:
            ERROR_RENDER.render_default = error_render

    async def start(
        self,
        host: str = "0.0.0.0",
        port: int = 8080,
        sock: Optional[socket.socket] = None,
        app_config: Optional[Dict] = None,
        executor_workers: Optional[int] = None,
        ssl: Optional[Union[ssl.SSLContext, Tuple[str]]] = None,
    ):
        if self._app is None:
            app_config = app_config or dict()
            self._init_app(**app_config)
        if self._executor_pools is None and executor_workers:
            self._init_executor_pool(executor_workers)
        self._set_default_render()
        self._init_routes()
        app = self._app
        if asyncio.iscoroutine(app):
            app = await app  # type: ignore
        runner = AppRunner(app)
        await runner.setup()
        if sock is None:
            sock = create_sock(host, port)
        if isinstance(ssl, tuple):
            ssl = load_ssl_context(*ssl)
        scheme = "https" if ssl else "http"
        self.web = SockSite(runner, sock, ssl_context=ssl)
        await self.web.start()
        logging.info("start web server in %s://%s:%s", scheme, host, port)


async def request_render(request: Request) -> Dict:
    """Parse request to a key-value object."""
    kwargs = dict()
    kwargs.update(request.query)
    kwargs.update(request.match_info)
    content_type = request.content_type.lower()
    if "json" in content_type:
        try:
            _kwargs = await request.json()
        except json.JSONDecodeError as e:
            raise ContentInvalidError("Invalid json-string: {e.args[0]}")
        kwargs.update(_kwargs)
    elif "form" in content_type:
        _kwargs = await request.post()
        kwargs.update(_kwargs)
    headers = dict(request.headers)
    send_trace(headers)
    return kwargs



async def json_request_render(request: Request) -> Dict:
    """Parse request with json content-type to a key-value object."""
    try:
        kwargs = await request.json()
    except json.JSONDecodeError as e:
        raise ContentInvalidError("Invalid json-string: {e.args[0]}")
    headers = dict(request.headers)
    send_trace(headers)
    return kwargs


async def form_request_render(request: Request) -> Dict:
    """Parse request with form content-type to a key-value object."""
    kwargs = await request.post()
    headers = dict(request.headers)
    send_trace(headers)
    return kwargs


async def simple_request_render(request: Request) -> Dict:
    """Parse request with form content-type to a key-value object."""
    kwargs = dict()
    kwargs.update(request.query)
    kwargs.update(request.match_info)
    headers = dict(request.headers)
    send_trace(headers)
    return kwargs


def response_render(ret: Any) -> Response:
    """Convert function returned to web response.

    This function is to change the value of target function returned
    to make it more restful.

    Args:
        ret (Any): value of the target function returned

    Returns:
        Response: a rest-like dict result
    """
    if ret is None:
        ret = {"status": "success"}
    elif isinstance(ret, (str, int, bytes, float)):
        ret = {"result": ret}
    ret = {"code": 200, "msg": "ok", "data": ret}
    return json_response(ret, dumps=dumps)


def page_response_render(ret: Any) -> Response:
    """Convert function returned to web page response.

    This function is to change the value of target function returned
    to make it more restful.

    Args:
        ret (Any): value of the target function returned

    Returns:
        Response: a rest-like dict result
    """
    if isinstance(ret, tuple) and len(ret) == 3:
        page, count, data = ret
        ret = {"code": 200, "msg": "ok", "data": data, "page": page, "count": count}
    elif isinstance(ret, dict):
        ret = dict(code=200, msg="ok", **ret)
    return json_response(ret, dumps=dumps)


def error_render(error: BaseException) -> Response:
    """Handle error and convert it to web response.

    This function is to deal with the probloms what to show for user
    when the target function can not be done properly and raise the
    exceptions. And to make it more restful, it would analysis the error
    and get some value from the error.

    Args:
        error (BaseException): the exception of the target function raise
    Returns:
        Response: a rest-like dict result with error info
    """
    if isinstance(error, BaseDrpcException):
        code = error.code
        if error.args:
            msg = ",".join(error.args)
        else:
            msg = error.message
    else:
        code = 500
        # msg = traceback.format_tb(error.__traceback__)
        # msg = "\n".join(msg)
        sio = io.StringIO()
        traceback.print_exception(type(error), error, error.__traceback__, None, sio)
        msg = sio.getvalue()
        sio.close()
        logging.error("got a unexpect error {}".format(error), exc_info=error)
    ret = {"code": code, "msg": msg}
    return json_response(data=ret, status=code)
