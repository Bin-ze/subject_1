#!/usr/bin/env python3
# -*- coding:UTF-8 -*-
# @Date    : 2021-07-13 11:42:46
# @Author  : Shenchucheng (chuchengshen@fuzhi.ai)
# @Desc    : base web server


import asyncio
import socket

from uuid import uuid4
from typing import Dict, Optional
from concurrent.futures.thread import ThreadPoolExecutor

from drpc.utils.log import parse as parse_log
from drpc.utils.config import load_config
from drpc.utils.context import send_trace


class BaseServer(object):
    _app = None
    _executor_pools: Optional[ThreadPoolExecutor] = None
    _routes: Dict

    def _trans_to_aiohttp(self):
        raise NotImplementedError

    def _trans_to_sanic(self):
        raise NotImplementedError

    async def start(self):
        raise NotImplementedError

    def run(
        self,
        *args,
        log: Optional[Dict] = None,
        config: Optional[Dict] = None,
        **kwargs
    ) -> None:
        if config is not None:
            return self.run(config=None, **load_config(config))
        if log is None:
            log = dict()
        for key in tuple(kwargs.keys()):
            if key.startswith("log_"):
                log[key[4:]] = kwargs.pop(key)
        parse_log(**log)
        loop = asyncio.get_event_loop()
        loop.run_until_complete(self.start(*args, **kwargs))
        loop.run_forever()


def create_sock(host, port) -> socket.socket:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind((host, port))
    sock.listen()
    return sock
