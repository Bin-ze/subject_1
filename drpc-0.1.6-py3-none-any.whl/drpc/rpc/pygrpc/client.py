#!/usr/bin/env python3
# -*- coding:UTF-8 -*-
# @Date    : 2021-07-13 11:42:57
# @Author  : Shenchucheng (chuchengshen@fuzhi.ai)
# @Desc    : parse function to generate pb


import grpc


class GRpcClient(object):
    _stub_class: type

    def __init__(self, host: str = "[::]", port: int = 8090) -> None:
        self.SERVER_PATH = "{}:{}".format(host, port)

    async def __aenter__(self):
        channel = self._channel = grpc.aio.insecure_channel(self.SERVER_PATH)
        self._stub = self._stub_class(channel)

        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self._channel._close(None)
        del self._channel
        del self._stub
