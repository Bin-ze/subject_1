#!/usr/bin/env python3
# -*- coding:UTF-8 -*-
# @Date    : 2021-07-13 11:42:57
# @Author  : Shenchucheng (chuchengshen@fuzhi.ai)
# @Desc    : parse function to generate pb


import grpc

from typing import Tuple
from drpc.utils.context import get_trace, send_trace


class TraceServerInterceptor(grpc.ServerInterceptor):
    def intercept_service(self, continuation, handler_call_details):
        metadata = dict(handler_call_details.invocation_metadata)
        send_trace(metadata)
        return continuation(handler_call_details)


def set_trace_metadata(context):
    metadata = dict(context.invocation_metadata())
    send_trace(metadata)


def get_trace_metadata() -> Tuple:
    return tuple((k, v) for (k, v) in get_trace().items())
