#!/usr/bin/env python3
# -*- coding:UTF-8 -*-
# @Date    : 2021-07-13 11:42:57
# @Author  : Shenchucheng (chuchengshen@fuzhi.ai)
# @Desc    : parse function to generate pb


import asyncio

from functools import partial
from typing import Callable, Optional
from inspect import isasyncgenfunction, isgeneratorfunction
from concurrent.futures import ThreadPoolExecutor
from drpc.rpc.pygrpc.interceptors import set_trace_metadata


class _GRpcService(object):
    pass


def create_grpc_handler_method(
    method: Callable,
    name: str,
    reponse,
    executor: Optional[ThreadPoolExecutor] = None,
) -> Callable:
    keys = list(method.__annotations__.keys())
    if "return" in keys:
        keys.remove("return")

    def MessageToDict(obj):
        kwargs = dict()
        for key in keys:
            kwargs[key] = getattr(obj, key)
        return kwargs

    if asyncio.iscoroutinefunction(method):

        async def handle(request, context):
            set_trace_metadata(context)
            kwargs = MessageToDict(request)
            resp = await method(**kwargs)
            if hasattr(resp, "__dataclass_fields__"):
                resp = resp.__dict__
            return reponse(**resp)

    elif isasyncgenfunction(method):

        async def handle(request, context):
            set_trace_metadata(context)
            kwargs = MessageToDict(request)
            async for resp in method(**kwargs):
                if hasattr(resp, "__dataclass_fields__"):
                    resp = resp.__dict__
                yield reponse(**resp)

    elif isgeneratorfunction(method):

        async def handle(request, context):
            set_trace_metadata(context)
            kwargs = MessageToDict(request)
            for resp in method(**kwargs):
                if hasattr(resp, "__dataclass_fields__"):
                    resp = resp.__dict__
                yield reponse(**resp)

    elif executor:

        async def handle(request, context):
            set_trace_metadata(context)
            loop = asyncio.get_running_loop()
            kwargs = MessageToDict(request)
            _func = partial(method, **kwargs)
            resp = await loop.run_in_executor(executor, _func)
            if hasattr(resp, "__dataclass_fields__"):
                resp = resp.__dict__
            return reponse(**resp)

    else:

        async def handle(request, context):
            set_trace_metadata(context)
            kwargs = MessageToDict(request)
            resp = method(**kwargs)
            if hasattr(resp, "__dataclass_fields__"):
                resp = resp.__dict__
            return reponse(**resp)

    handle.__name__ = name
    return handle


def create_grpc_handle_obj(methods):
    service = _GRpcService()
    for method, name, reponse, executor in methods:
        handle = create_grpc_handler_method(method, name, reponse, executor)
        setattr(service, name, handle)
    return service
