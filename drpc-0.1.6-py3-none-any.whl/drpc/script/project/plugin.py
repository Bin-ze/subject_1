#!/usr/bin/env python3
# -*- coding:UTF-8 -*-
# @Date    : 2021-07-29 16:30:19
# @Author  : Shenchucheng (chuchengshen@fuzhi.ai)
# @Desc    : project console tools


import os
import black
import shutil
import jinja2
import pkg_resources

from fire import Fire
from typing import Callable
from grpc_tools import protoc
from drpc import __version__
from drpc.utils.log import parse


TEMPLATES = {
    "README.j2": "README.md",
    "setup.j2": "setup.py",
    "requirements.j2": "requirements.txt",
    "main.j2": "main.py",
    "gitlab-ci.j2": ".gitlab-ci.yml",
    "gitignore.j2": ".gitignore",
    "Docker.j2": "Dockerfile",
}


_PROTO_DEMO = """syntax = "proto3";

package demo.demo;

message ProbeRequest {
}

message ProbeResponse {
    string status = 1;
}

service Demo {
    // To reply heartbeat message.
    // HTTP: /probe GET,POST
    rpc probe (ProbeRequest) returns (ProbeResponse);
}
"""


class CodeGenTool(object):
    def create(self, method: str) -> Callable:
        """Create project/demo or rpc client/server code.

        Args:
            method (str): method must be one of project/demo/server/client.
        """
        if method not in ("project", "demo", "server", "client"):
            raise ValueError("invalid method")
        return getattr(self, "create_{}".format(method))
    
    def update(self, method: str) -> Callable:
        """Update project or server code if the proto file changed.

        Args:
            method (str): method must be one of project/server

        """
        if method not in ("server", "project"):
            raise ValueError("invalid method")
        return getattr(self, "update_{}".format(method))

    def create_project(
        self,
        project_name: str,
        proto: bool = True,
        use_orm: bool = True,
        use_redis: bool = True,
        create_config: bool = True,
        overwrite: bool = False,
    ) -> None:
        """Create a project by project_name.

        Args:
            project_name (str): the project name you want to create
            proto (bool, optional): whether to parse the proto files
            use_orm (bool, optional): whether to use orm module
            use_redis (bool, optional): whether to use redis module
            create_config (bool, optional): whether to creat config files
            overwrite (bool, optional): overwrite normal files if already existed
        """
        env = jinja2.Environment(
            trim_blocks=True,
            lstrip_blocks=True,
            loader=jinja2.FileSystemLoader("%s/templates/" % os.path.dirname(__file__)),
        )
        _TEMPLATES = dict((v, k) for k, v in TEMPLATES.items())
        configs = ["dev", "test", "prod"]
        if not overwrite:
            for file in tuple(_TEMPLATES.keys()):
                if os.path.exists(file):
                    if input("file {} already existed, do you want to replace it?[Y/N]".format(file)) != "Y":
                        _TEMPLATES.pop(file)
            for name in configs:
                file = os.path.join("config", name + ".yaml")
                if os.path.exists(file):
                    if input("file {} already existed, do you want to replace it?[Y/N]".format(file)) != "Y":
                        configs.remove(name)

        if os.path.exists(project_name):
            if proto:
                protos = list()
                for root, _, files in os.walk(project_name):
                    for j in files:
                        if j.endswith(".proto"):
                            protos.append(os.path.join(root, j))
                if protos:
                    from grpc_tools import protoc

                    proto_include = pkg_resources.resource_filename("grpc_tools", "_proto")
                    command_arguments = [
                        protoc.__file__,
                        "-I.",
                        "--python_out=.",
                        "--grpc_python_out=.",
                        "--python_drpc_server_out=.",
                        *protos,
                        "-I{}".format(proto_include),
                    ]
                    protoc.main(command_arguments)
        else:
            os.mkdir(project_name)
        infos = dict()
        infos["project_name"] = project_name
        infos["use_orm"] = use_orm
        infos["use_redis"] = use_redis
        infos["drpc_version"] = __version__
        for outpot, name in _TEMPLATES.items():
            template = env.get_template(name)
            content = template.render(**infos)
            if outpot.endswith(".py"):
                content = black.format_str(
                    content,
                    mode=black.FileMode(target_versions=set([black.TargetVersion.PY37])),
                )
            with open(outpot, "w") as f:
                f.write(content)
        if create_config and not os.path.exists("config"):
            os.mkdir("config")
        if configs:
            for name in configs:
                file = os.path.join("config", name + ".yaml")
                with open(os.path.join(file), "w") as f:
                    f.write(env.get_template("config.j2").render(**infos))
        if os.path.exists("__init__.py"):
            os.remove("__init__.py")

    def create_demo(self, overwrite: bool = False, **kwargs) -> None:
        """Create a demo project named 'demo' with proto.

        Args:
            overwrite (bool, optional): overwrite folder if `demo` already existed

        """
        if os.path.exists("demo"):
            if overwrite:
                shutil.rmtree("demo")
            else:
                raise FileExistsError("demo already existe, please remove it!")
        os.mkdir("demo")
        with open(os.path.join("demo", "demo.proto"), "w") as f:
            f.write(_PROTO_DEMO)
        _kwargs = {
            "use_orm": False,
            "use_redis": False,
        }
        _kwargs.update(kwargs)
        return self.create_project("demo", overwrite=overwrite, **_kwargs)

    def create_client(
        self, proto: str,
        *protos: str,
        python_out: str = ".",
        grpc_python_out: str = ".",
        python_drpc_client_out: str = "."
    ) -> None:
        """Create rpc client from proto files.

        Args:
            proto (str): proto files
            python_out (str, optional): the python code output directory
            grpc_python_out (str, optional): the grpc code output directory
            python_drpc_client_out (str, optional): the rpc client output directory
        """
        protos = list(protos)
        protos.append(proto)
        proto_include = pkg_resources.resource_filename("grpc_tools", "_proto")
        command_arguments = [
            protoc.__file__,
            "-I.",
        ]
        if python_out:
            command_arguments.append("--python_out={}".format(python_out))
        if grpc_python_out:
            command_arguments.append("--grpc_python_out={}".format(grpc_python_out))
        command_arguments.append("--python_drpc_client_out={}".format(python_drpc_client_out))
        command_arguments.extend(protos)
        command_arguments.append("-I{}".format(proto_include))
        protoc.main(command_arguments)

    def create_server(
        self, proto: str, *protos: str, python_out: str = ".", grpc_python_out: str = ".", python_drpc_server_out: str = "."
    ) -> None:

        """Create rpc server from proto files.

        Args:
            proto ([type]): proto files
            python_out (str, optional): the python code output directory
            grpc_python_out (str, optional): the grpc code output directory
            python_drpc_client_out (str, optional): the rpc client output directory
        """
        protos = list(protos)
        protos.append(proto)
        proto_include = pkg_resources.resource_filename("grpc_tools", "_proto")
        command_arguments = [
            protoc.__file__,
            "-I.",
        ]
        if python_out:
            command_arguments.append("--python_out={}".format(python_out))
        if grpc_python_out:
            command_arguments.append("--grpc_python_out={}".format(grpc_python_out))
        command_arguments.append("--python_drpc_server_out={}".format(python_drpc_server_out))
        command_arguments.extend(protos)
        command_arguments.append("-I{}".format(proto_include))
        protoc.main(command_arguments)

    def update_project(
        self,
        project_name: str
    ) -> None:
        """Update a project by project_name when the proto file has been changed.

        Args:
            project_name (str): project name
        """
        if not os.path.exists(project_name):
            raise FileNotFoundError("project named {} folder not found".format(project_name))
        protos = list()
        for root, _, files in os.walk(project_name):
            for file in files:
                if file.endswith(".proto"):
                    protos.append(os.path.join(root, file))
        if not protos:
            raise FileNotFoundError("proto file not found in {}".format(project_name))
        proto_include = pkg_resources.resource_filename("grpc_tools", "_proto")
        command_arguments = [
            protoc.__file__,
            "-I.",
            "--python_drpc_update_server_out=.",
            "--python_out=.",
            "--grpc_python_out=.",
            *protos,
            "-I{}".format(proto_include)
        ]
        protoc.main(command_arguments)

    def __call__(self, **kwargs):
        if "version" in kwargs:
            return  __version__


def main():
    parse()
    Fire(CodeGenTool())


if __name__ == "__main__":
    main()
