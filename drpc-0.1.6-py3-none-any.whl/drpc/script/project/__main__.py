#!/usr/bin/env python3
# -*- coding:UTF-8 -*-
# @Date    : 2021-07-29 16:30:19
# @Author  : Shenchucheng (chuchengshen@fuzhi.ai)
# @Desc    : project console tools


from drpc.script.project.plugin import main


if __name__ == "__main__":
    main()
